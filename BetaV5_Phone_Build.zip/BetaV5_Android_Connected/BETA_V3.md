# Beta V3 feature map

Chat -> OpenAI Responses API + web search
Memory -> persistent local JSON (development)
PDF -> stored extracted text + document Q&A
Voice -> secure realtime-session architecture; no API key in APK

Next production work:
1. Deploy backend with HTTPS.
2. Add authentication.
3. Replace JSON memory with a database.
4. Add real file/vector search for large PDFs.
5. Issue short-lived voice sessions from backend.
6. Connect Android UI to these endpoints.
