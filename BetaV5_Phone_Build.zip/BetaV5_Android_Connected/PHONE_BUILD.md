# Beta V5 — Phone-only APK build

Android Studio is not required on your phone. This project includes a GitHub Actions workflow that builds the APK in GitHub's cloud.

## From an Android phone
1. Upload this project to your GitHub repository `alpha12356-cmyk/Beta-Ai` (or replace the repository contents).
2. Open the repository on GitHub.
3. Tap **Actions** → **Build Beta APK** → **Run workflow**.
4. Wait for the green check.
5. Open the completed workflow run and download the artifact **Beta-debug-apk**.
6. Extract the downloaded ZIP and install `app-debug.apk` on your phone.

No OpenAI API key is placed in the Android app. The app talks to the Render backend configured in `MainActivity.kt`.
