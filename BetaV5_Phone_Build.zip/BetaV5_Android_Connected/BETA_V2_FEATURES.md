# Beta V2

## Working backend pieces
- Chat
- Web search tool
- Basic demo memory API
- Health check

## PDF
The `/pdf` route is deliberately a scaffold rather than pretending to have persistent PDF search.
Next implementation: persistent file upload + vector/file search + per-user access control.

## Production hardening
- HTTPS
- authentication
- rate limiting
- persistent database
- encrypted secrets
- request logging without sensitive content
- Android permission gates for device actions
