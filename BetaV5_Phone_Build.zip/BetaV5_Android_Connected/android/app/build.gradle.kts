plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}
android {
    namespace = "com.beta.assistant"
    compileSdk = 35
    defaultConfig {
        applicationId = "com.beta.assistant"
        minSdk = 26
        targetSdk = 35
        versionCode = 2
        versionName = "1.1"
    }
}

// Java's HttpURLConnection is used for the small backend client, so no networking SDK is required.
