package com.beta.assistant

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.speech.RecognizerIntent
import android.speech.tts.TextToSpeech
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import java.io.BufferedReader
import java.io.InputStreamReader
import java.net.HttpURLConnection
import java.net.URL
import java.util.Locale
import org.json.JSONObject
import java.util.concurrent.Executors

class MainActivity : Activity(), TextToSpeech.OnInitListener {
    // Live Render backend URL — no API key is stored in the app.
    private val backendUrl = "https://beta-ai-8ht3.onrender.com"
    private lateinit var input: EditText
    private lateinit var chat: TextView
    private lateinit var tts: TextToSpeech
    private val executor = Executors.newSingleThreadExecutor()
    private val speechRequest = 1001

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        input = findViewById(R.id.input)
        chat = findViewById(R.id.chat)
        tts = TextToSpeech(this, this)

        findViewById<Button>(R.id.send).setOnClickListener { sendMessage() }
        findViewById<Button>(R.id.mic).setOnClickListener { startVoiceInput() }
    }

    private fun sendMessage() {
        val text = input.text.toString().trim()
        if (text.isEmpty()) return
        addMessage("You", text)
        input.text.clear()
        findViewById<Button>(R.id.send).isEnabled = false
        executor.execute {
            val reply = postChat(text)
            runOnUiThread {
                findViewById<Button>(R.id.send).isEnabled = true
                addMessage("Beta", reply)
                speak(reply)
            }
        }
    }

    private fun postChat(message: String): String {
        return try {
            val url = URL("$backendUrl/chat")
            val conn = (url.openConnection() as HttpURLConnection).apply {
                requestMethod = "POST"
                connectTimeout = 15000
                readTimeout = 60000
                doOutput = true
                setRequestProperty("Content-Type", "application/json")
                setRequestProperty("X-Beta-User", "android-demo-user")
            }
            val body = "{\"message\":${jsonString(message)}}"
            conn.outputStream.use { it.write(body.toByteArray(Charsets.UTF_8)) }
            val stream = if (conn.responseCode in 200..299) conn.inputStream else conn.errorStream
            val response = BufferedReader(InputStreamReader(stream)).use { it.readText() }
            try {
                JSONObject(response).optString("reply", "Backend error: $response")
            } catch (_: Exception) {
                "Backend error: $response"
            }
        } catch (e: Exception) {
            "Beta backend se connect nahi ho paaya. Server URL aur network check karo. (${e.javaClass.simpleName})"
        }
    }

    private fun jsonString(value: String): String =
        "\"" + value.replace("\\", "\\\\").replace("\"", "\\\"").replace("\n", "\\n") + "\""

    private fun addMessage(who: String, text: String) {
        chat.append("\n\n$who: $text")
    }

    private fun startVoiceInput() {
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), speechRequest)
            return
        }
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "hi-IN")
            putExtra(RecognizerIntent.EXTRA_PROMPT, "Beta ko bolo...")
        }
        startActivityForResult(intent, speechRequest)
    }

    @Deprecated("Deprecated in Android API; retained for starter simplicity")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == speechRequest && resultCode == RESULT_OK) {
            val results = data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)
            input.setText(results?.firstOrNull().orEmpty())
        }
    }

    override fun onInit(status: Int) {
        if (status == TextToSpeech.SUCCESS) tts.language = Locale("hi", "IN")
    }

    private fun speak(text: String) {
        tts.speak(text, TextToSpeech.QUEUE_FLUSH, null, "beta_reply")
    }

    override fun onDestroy() {
        executor.shutdownNow()
        tts.stop()
        tts.shutdown()
        super.onDestroy()
    }
}
