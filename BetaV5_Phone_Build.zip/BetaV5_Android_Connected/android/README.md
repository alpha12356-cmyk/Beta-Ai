# Beta V5 — Android Connected

Beta is a Hindi/Hinglish personal AI assistant starter app.

## Included now
- Basic Android chat UI
- Hindi speech-to-text using Android SpeechRecognizer
- Hindi text-to-speech
- No API key embedded in the APK

## Backend connection
The app is already connected to the deployed HTTPS Beta backend. Backend URL: `https://beta-ai-8ht3.onrender.com`. Do NOT put an OpenAI API key directly in the Android app.

## Build
Open this folder in Android Studio, let Gradle sync, then Run on an Android 8.0+ device/emulator.

## Planned Beta features
1. AI chat
2. Voice conversation
3. Web search
4. Memory
5. PDF/document Q&A
6. Safe Android actions
7. Custom commands