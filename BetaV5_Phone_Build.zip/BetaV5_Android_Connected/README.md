# Beta V5 — Connected Android + Live Render Backend

Beta is a Hindi/Hinglish personal AI assistant starter connected to a secure Node.js backend.

## Included
- Android chat UI connected to `/chat`
- Hindi speech-to-text and text-to-speech
- GPT-5.6 Luna via OpenAI Responses API
- Web search tool on the backend
- Persistent demo memory endpoints
- PDF/document text storage + Q&A starter
- API key stays on the backend, never in the APK

## Important
The Android app is preconfigured to use the deployed HTTPS backend:
`https://beta-ai-8ht3.onrender.com`

The APK contains no OpenAI API key. The phone talks only to the Render backend, and the backend talks to OpenAI.

## Backend
1. `cd backend`
2. Copy `.env.example` to `.env`
3. Put your OpenAI API key in `.env` privately. Never paste it into chat or commit it.
4. `npm install`
5. `npm start`

## Android
Open `android/` in Android Studio, sync Gradle, then run on an emulator/device.

## Current setup
- Android → HTTPS → Render (`beta-ai-8ht3.onrender.com`) → OpenAI
- OpenAI key remains on Render, not in the Android app.
- Render's free service may sleep when idle, so the first request after inactivity can take longer.

## Production
Use an HTTPS backend, real authentication, a database/object storage, and proper PDF uploads/file search.
