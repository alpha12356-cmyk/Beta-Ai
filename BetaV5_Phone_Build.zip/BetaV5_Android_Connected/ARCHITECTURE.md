# Beta V1 Real AI architecture

Android app -> secure HTTPS backend -> OpenAI Responses API

The API key lives only on the backend.

Next additions:
- web search tool on the backend
- file/PDF search
- persistent memory database
- authenticated user sessions
- Android actions with explicit user permission
- realtime voice
